# Nginx Routes Deployment Instructions

## Files to upload to production server:

1. **routes/nginx-config.js** - Contains nginx domain management routes
2. **server.js** - Main server file with route registration
3. **package.json** - Dependencies

## Routes that will be added:

- POST /api/nginx/validate-domain
- POST /api/nginx/add-domain  
- GET /api/nginx/test-config
- POST /api/nginx/reload-config

## Deployment Steps:

1. Stop the production server
2. Upload these files to /var/www/nginx-control-panel/
3. Run: npm install (if new dependencies)
4. Restart the server: node server.js
5. Test the nginx routes

## Verification:

Test that the nginx routes work:
```bash
curl -X POST https://sitedev.eezix.com/api/nginx/validate-domain \
  -H "Content-Type: application/json" \
  -d '{"domain":"test.com"}'
```

Should return: {"valid":true}
