#!/bin/bash

echo "=== SSL Certificate Manager - Production Deployment ==="
echo

# Install dependencies
echo "1. Installing Node.js dependencies..."
npm install

# Set up systemd service
echo "2. Creating systemd service file..."
sudo tee /etc/systemd/system/nginx-control-panel.service > /dev/null << 'SERVICE_EOF'
[Unit]
Description=SSL Certificate Manager
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/nginx-control-panel
Environment=NODE_ENV=production
Environment=PORT=8000
ExecStart=/usr/bin/node server.js
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
SERVICE_EOF

# Reload systemd and enable service
echo "3. Setting up systemd service..."
sudo systemctl daemon-reload
sudo systemctl enable nginx-control-panel.service

# Set proper permissions
echo "4. Setting file permissions..."
sudo chown -R www-data:www-data /var/www/nginx-control-panel
sudo chmod +x /var/www/nginx-control-panel/create-domain.sh

# Start the service
echo "5. Starting SSL Certificate Manager..."
sudo systemctl start nginx-control-panel.service

# Check status
echo "6. Checking service status..."
sudo systemctl status nginx-control-panel.service

echo
echo "✓ Deployment complete!"
echo "✓ Service: nginx-control-panel"
echo "✓ Status: sudo systemctl status nginx-control-panel"
echo "✓ Logs: sudo journalctl -u nginx-control-panel -f"
echo "✓ Restart: sudo systemctl restart nginx-control-panel"
echo
echo "Test the endpoints:"
echo "curl -X GET https://sitedev.eezix.com/api/domains"
echo "curl -X POST https://sitedev.eezix.com/api/domains/validate -H 'Content-Type: application/json' -d '{\"domain\":\"test.com\"}'"

