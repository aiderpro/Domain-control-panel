#!/bin/bash

echo "=== SSL Certificate Manager - PM2 Deployment ==="
echo

# Install dependencies
echo "1. Installing Node.js dependencies..."
npm install

# Install PM2 if not installed
if ! command -v pm2 &> /dev/null; then
    echo "2. Installing PM2..."
    sudo npm install -g pm2
fi

# Create PM2 ecosystem file
echo "3. Creating PM2 configuration..."
cat > ecosystem.config.js << 'PM2_EOF'
module.exports = {
  apps: [{
    name: 'ssl-manager',
    script: 'server.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 8000
    }
  }]
};
PM2_EOF

# Stop any existing process
echo "4. Stopping existing PM2 processes..."
pm2 delete ssl-manager 2>/dev/null || true

# Start with PM2
echo "5. Starting SSL Certificate Manager with PM2..."
pm2 start ecosystem.config.js

# Save PM2 configuration
echo "6. Saving PM2 configuration..."
pm2 save

# Set up PM2 startup
echo "7. Setting up PM2 startup..."
pm2 startup

# Set proper permissions
echo "8. Setting file permissions..."
sudo chown -R www-data:www-data /var/www/nginx-control-panel
sudo chmod +x /var/www/nginx-control-panel/create-domain.sh

# Show status
echo "9. Checking PM2 status..."
pm2 status

echo
echo "✓ Deployment complete!"
echo "✓ Process: ssl-manager"
echo "✓ Status: pm2 status"
echo "✓ Logs: pm2 logs ssl-manager"
echo "✓ Restart: pm2 restart ssl-manager"
echo
echo "Test the endpoints:"
echo "curl -X GET https://sitedev.eezix.com/api/domains"
echo "curl -X POST https://sitedev.eezix.com/api/domains/validate -H 'Content-Type: application/json' -d '{\"domain\":\"test.com\"}'"

